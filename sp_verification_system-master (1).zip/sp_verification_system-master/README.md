# sp_verification_system
Security Protocol Verification System

Welcome to SP Verification System!

To run verification tool You must run program in terminal. Next, You must choose the security protocol to verify. The results of verification are plased in result/protcol folder in file protcol_attack.txt.
